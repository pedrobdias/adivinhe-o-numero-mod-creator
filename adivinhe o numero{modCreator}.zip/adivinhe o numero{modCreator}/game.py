print('show import list{}')
print('[number, port, hacker]')
print('> import: number{')
pr = int(input('    '))
print('},')
sg = input('> print: ')
te = input('> run')
n1 = pr
print('Bem vindo, adivinhe o numero, boa sorte.')
print('{}'.format(sg))
number1 = int(input('numero aqui > '))
if number1 == n1:
    print('você acertou')
else:
    print('você errou')

